Heritage Flow India — polished website package

Files included:
- index.html: complete single-page website, styling and interactions
- favicon.svg: browser tab icon
- heritage-flow-preview.png: 1200 x 630 social-sharing preview

To update the existing Netlify site:
1. Extract this ZIP into a folder.
2. Keep all three files together in that folder.
3. Open the site's Netlify dashboard, go to Deploys, and upload/drag the extracted folder to the deploy dropzone.
4. Wait for the deploy to finish, then refresh https://heritageflowindia.netlify.app/ in a private/incognito window.

The canonical and social-preview URLs in index.html point to https://heritageflowindia.netlify.app/. If the site's URL changes, update the canonical, og:url, og:image, and twitter:image values first.

Accuracy note: the visit-planning score is illustrative, not live crowd data or a trained AI prediction. Online search and nearby-place lookup rely on public map data and an internet connection.
